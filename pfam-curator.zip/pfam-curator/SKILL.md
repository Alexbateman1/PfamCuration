---
name: pfam-curator
description: Guide for curating protein family entries in the Pfam database. Use when creating or editing Pfam family DESC files, annotating protein domains and families, assigning clans, iterating families, and following Pfam curation standards for IDs, definitions, comments, and references.
---

# Pfam Curator

This skill provides guidance for curating entries in the Pfam protein family database. It covers creating new families, editing existing ones, writing annotations, and following Pfam standards.

## Core Principles

1. **Factual over speculative**: Only include experimentally verified information
2. **Gene names over DUFs**: Use available gene names (YfdP, Rv1109c) rather than defaulting to Domain of Unknown Function
3. **Concise annotations**: Keep CC lines under 75 characters, start with "This entry represents..."
4. **British English**: Use British spellings (localised, organisation, characterised)
5. **No speculation**: Avoid "may", "could", "possibly", "suggests" for uncharacterised functions

## Quick Reference

### Key Files in a Pfam Entry

- **DESC**: Annotation file (ID, DE, AC, AU, CC, references)
- **SEED**: Multiple sequence alignment (curated representatives)
- **HMM**: Profile hidden Markov model (auto-generated from SEED)
- **PFAMOUT**: Search results against pfamseq database
- **ALIGN**: Full alignment of all matches above threshold
- **scores**: Bit scores for matches

### Essential Commands

```bash
pfco PF00100          # Check out family from SVN
pfci -m 'message'     # Check in with commit message
pfnew dir_name        # Add new family
pfinfo PF00100        # View family info without checkout
pfbuild               # Build HMM and search pfamseq
pfmake -e 0.01        # Make ALIGN from PFAMOUT with E-value threshold
```

## Naming Conventions

### ID Line Format

- **Length**: 15 characters or less (extended to 30, but keep short)
- **Capitalization**: First letter capitalized
- **Separators**: Underscores for spaces, hyphens only for actual hyphens
- **No slashes**: Replace / with _
- **Avoid redundancy**: Don't use "domain", "repeat", "family" in ID (encoded in TP line)

### Positional Suffixes

- `_N` - N-terminal domain
- `_C` - C-terminal domain  
- `_M` - Middle domain
- `_1st`, `_2nd`, `_3rd` - For multidomain proteins (preferred ECOD style)

### Special Prefixes

- `WHD_` - For Winged Helix domains

### ID Examples

```
Good: Zona_pellucida, EGF_alliinase, RNA_pol_Rpb2_45
Avoid: Zona_pellucida_domain, EGF_repeat, RNA_family
```

## DESC File Structure

See [references/desc-format.md](references/desc-format.md) for complete field specifications.

### Field Order (CRITICAL)

**Header section** (in this order):
```
ID   Short_name
AC   PF00000
DE   One-line definition (80 chars max)
AU   Author A;0000-0000-0000-0000
SE   Source of seed
GA   25.00 25.00;
TC   25.00 25.00;
NC   24.90 24.90;
BM   hmmbuild -o /dev/null HMM SEED
SM   hmmsearch -Z 47079205 -E 1000 --cpu 4 HMM pfamseq
TP   Family|Domain|Repeat|Motif|Coiled-coil|Disordered
PI   previous_id; (optional)
CL   CL0000 (optional, if in clan)
```

**Reference section** (MUST come BEFORE CC lines):
```
WK   Wikipedia_article_name (optional)
RC   Reference comment (optional)
RN   [1]
RM   12345678
RT   Paper title
RT   continued on next line if needed
RA   Authors;
RL   Journal 2023;123:456-789.
DR   DATABASE; identifier; (optional)
```

**Comment section** (ALWAYS LAST):
```
CC   This entry represents...
CC   (continued annotation)
```

### Complete Example (Correct Order)

```
ID   CBS
AC   PF00571
DE   CBS domain
AU   Bateman A;0000-0002-6982-4660
SE   [1]
GA   24.00 16.50;
TC   24.00 16.50;
NC   23.90 16.40;
BM   hmmbuild -o /dev/null HMM SEED
SM   hmmsearch -Z 90746521 --cpu 8 -E 1000 HMM pfamseq
TP   Domain
WK   CBS_domain
RC   Discovery and naming of the CBS domain.
RN   [1]
RM   9020585
RT   The structure of a domain common to archaebacteria and the
RT   homocystinuria disease protein.
RA   Bateman A;
RL   Trends Biochem Sci 1997;22:12-13.
RN   [2]
RM   10200156
RT   Characteristics and crystal structure of bacterial
RT   inosine-5'-monophosphate dehydrogenase.
RA   Zhang R, Evans G, Rotella FJ, Westbrook EM, Beno D, Huberman E,
RA   Joachimiak A, Collart FR;
RL   Biochemistry 1999;38:4691-4700.
CC   CBS domains are small intracellular modules that pair together to
CC   form a stable globular domain [2]. This family represents a single
CC   CBS domain. CBS domains have been shown to bind ligands with an
CC   adenosyl group such as AMP, ATP and S-AdoMet.
```

**CRITICAL**: References (RN/RM/RT/RA/RL) MUST come BEFORE CC lines!

## Writing CC Lines (Comments)

See [references/writing-guidelines.md](references/writing-guidelines.md) for detailed guidance.

### Structure

1. **Opening**: "This entry represents the [domain/family/repeat] [name]"
2. **Taxonomy**: "found in [organisms/taxonomic groups]" (when specific)
3. **Size/Structure**: Length, structural features, conserved residues
4. **Function**: Only experimentally verified functions with citations
5. **Architecture**: Other domains present (factual observation only)
6. **Closure**: "The function of this [domain/protein] remains to be determined" (if unknown)

### What to Include

✓ Experimentally verified functions [cite]
✓ Structural features (alpha-helices, beta-sheets, zinc fingers)
✓ Conserved sequence motifs (short diagnostic sequences)
✓ Domain architecture (other domains present)
✓ Taxonomic distribution (when informative)
✓ Subcellular localisation (if experimentally determined)
✓ Database annotations (COG, NCBIfam identifiers)

### What to Avoid

✗ Speculation based on genomic context
✗ Inferred functions from similarity alone
✗ Phrases: "may be", "could be", "possibly", "suggests"
✗ Long motifs (>20 residues)
✗ Complete genome paper citations
✗ Copyright-protected content reproduction

### Example CC Section

```
CC   This entry represents the Zona pellucida domain found in 
CC   extracellular proteins involved in fertilisation. The domain is
CC   approximately 260 residues long and contains a conserved pattern of
CC   cysteine residues forming disulfide bonds [1]. It is found in egg
CC   coat proteins ZP1, ZP2, and ZP3, as well as transforming growth
CC   factor-beta receptor type III.
```

## Annotation Sources

### Priority Order

1. **Reviewed UniProt** (SwissProt) - Most reliable
2. **PDB structures** - Experimental evidence
3. **Primary literature** - Characterisation studies
4. **InterPro** - Cross-database annotations
5. **Organism databases** (HGNC, FlyBase, TAIR)
6. **TrEMBL** - Unreviewed, use cautiously

### Search Strategy

Use PubMed for finding characterisation papers:

```
Family domain characterisation
Gene_name protein function
Structure function analysis
```

Prioritise papers with:
- Experimental validation (biochemistry, genetics)
- Structural determination
- Functional characterisation
- Organism-specific studies

Avoid:
- Complete genome papers (rarely informative for specific families)
- Papers only describing DNA sequences
- Review papers without new data

## Type Field (TP)

Choose based on evidence:

- **Family**: Default for complete proteins or uncertain classification
- **Domain**: Clear structural/functional domain with defined boundaries
- **Repeat**: Tandem or dispersed repeated sequences
- **Motif**: Short linear motifs (rare in Pfam)
- **Coiled-coil**: Predominantly coiled-coil structure
- **Disordered**: No stable structure, often biased composition

## Clan Assignment

Add `CL   CLxxxx` line when families share common ancestry via:

1. **ECOD classification** - Most reliable, structural evidence
2. **Foldseek comparison** - AlphaFold model structural similarity
3. **Overlaps** - Extensive overlaps suggesting homology
4. **SCOOP2** - Pfam family relationship predictions
5. **Jackhmmer** - Iterative search revealing relationships

### When to Create New Clan

- Multiple related families without existing clan
- Clear structural/sequence/functional similarity
- ECOD places families in same superfamily

## Iteration Workflow

See [references/workflows.md](references/workflows.md) for detailed procedures.

### Basic Iteration

```bash
# Check out family
pfco PF00100
cd PF00100

# View and extend alignment
belvu ALIGN
extend.pl -n 30 -c 30 -align ALIGN -m > extended
belvu extended  # Edit and save as SEED

# Rebuild
pfbuild
pfmake -e 0.01
belvu ALIGN  # Check results

# Repeat until no new sequences found
```

### Quality Control

```bash
# Check overlaps and DESC format
pqc-all directory_name id

# Check specific issues
pqc-overlap-rdb directory_name id
```

Resolve overlaps by:
1. Trimming boundaries
2. Raising thresholds
3. Adding to clan (if related)
4. Using ED lines (exceptional cases only)

## Working with Structures

### AlphaFold Models

Access models at AFDB or UniProt AlphaFold interface. High pLDDT (>70) indicates confident predictions.

### ECOD Integration

Use ECOD classification to:
- Determine domain boundaries
- Identify clan membership
- Split multidomain families
- Validate structural classification

### TED Domains

TED (Tandem domain boundaries within proteins) helps:
- Identify domain boundaries in AlphaFold models
- Split Pfam families into constituent domains
- Find missing domains in proteins

## Special Cases

### DUF Families

When function is unknown:

```bash
# Assign next DUF number
nextDUF.pl  # Run from working directory
```

DESC file format:
```
ID   DUF (number assigned automatically)
DE   Domain of unknown function (DUFxxxx)
TP   Domain|Family
WK   Domain_of_unknown_function
CC   This entry represents a domain of unknown function found in
CC   [taxonomic distribution]. The domain is approximately [length]
CC   residues long. [Any notable features: conserved residues,
CC   structure, etc.]. The function of this domain remains to be
CC   determined.
```

### Single Sequence SEEDs

Avoid singleton SEEDs when possible. Iterate to find related sequences:

```bash
# Get list of singletons
/homes/agb/Scripts/get_single_seq_seeds.pl

# Iterate to expand
iterate.py family_directory
```

### Non-Reference Proteome Sequences

When including sequences outside Reference Proteomes:

```bash
# Build against full UniProt
pfbuild -db uniprot

# Liftover to pfamseq sequences
liftover_alignment.pl -align SEED
# Edit resulting SEED.phmmer, save as SEED

# Continue normal workflow
pfbuild
pfmake
```

## Memory and Performance

For large families that exceed default memory:

```bash
# Request more memory
pfbuild -M 5  # 5GB

# Or use batch system
sbatch --partition=production --mem=5G --output=pfbuild.log \
  --job-name=pfbuild --wrap='pfbuild'

# Interactive session
salloc -t 01:00:00 --mem 8GB
# Then run commands
```

## References and Tools

- **Belvu**: Alignment viewer/editor
- **Pfetch**: Retrieve sequences by accession
- **Dotter**: Self-comparison for repeat identification
- **Foldseek**: Structural similarity search
- **HMMER3**: Profile HMM software
- **InterPro**: Integrated protein family database

## Common Workflows

For complete workflow documentation, see:
- [references/workflows.md](references/workflows.md) - Step-by-step procedures
- [references/desc-format.md](references/desc-format.md) - DESC field specifications
- [references/writing-guidelines.md](references/writing-guidelines.md) - Annotation standards
