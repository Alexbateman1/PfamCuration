# DESC File Format Reference

Complete specification of all fields in a Pfam DESC file.

## CRITICAL: Field Order

The DESC file has three main sections that MUST appear in this order:

1. **Header Section**: ID through TP (and optional PI, CL)
2. **Reference Section**: WK, RC, RN, RM, RT, RA, RL, DR
3. **Comment Section**: CC lines (ALWAYS LAST)

**Common Mistake**: Placing CC lines before references. This is incorrect!

### Correct Order Example

```
ID   CBS
AC   PF00571
DE   CBS domain
AU   Bateman A;0000-0002-6982-4660
SE   [1]
GA   24.00 16.50;
TC   24.00 16.50;
NC   23.90 16.40;
BM   hmmbuild -o /dev/null HMM SEED
SM   hmmsearch -Z 90746521 --cpu 8 -E 1000 HMM pfamseq
TP   Domain
CL   CL0159
WK   CBS_domain
RC   Discovery and naming of the CBS domain.
RN   [1]
RM   9020585
RT   The structure of a domain common to archaebacteria and the
RT   homocystinuria disease protein.
RA   Bateman A;
RL   Trends Biochem Sci 1997;22:12-13.
RN   [2]
RM   10200156
RT   Characteristics and crystal structure of bacterial
RT   inosine-5'-monophosphate dehydrogenase.
RA   Zhang R, Evans G, Rotella FJ, Westbrook EM, Beno D, Huberman E,
RA   Joachimiak A, Collart FR;
RL   Biochemistry 1999;38:4691-4700.
CC   CBS domains are small intracellular modules that pair together to
CC   form a stable globular domain [2]. This family represents a single
CC   CBS domain. CBS domains have been shown to bind ligands with an
CC   adenosyl group such as AMP, ATP and S-AdoMet.
```

Note: References (RN/RM/RT/RA/RL) come BEFORE CC lines!

## Header Section (Required Fields)

### AC - Accession Number
**Format**: `AC   PFxxxxx`
**Example**: `AC   PF00100`
- Stable identifier assigned automatically by system
- Never manually edit this field
- Format: PF followed by 5 digits

### ID - Identification
**Format**: `ID   Short_name`
**Length**: 15 characters or less (extended to 30, but keep short)
**Example**: `ID   Zona_pellucida`

**Rules**:
- Capitalise first letter
- Use underscores for spaces
- Hyphens only for actual hyphens  
- No slashes (replace with underscore)
- Avoid "domain", "repeat", "family" (encoded in TP line)
- Domain comes before protein name (e.g., `EGF_Tenascin` not `Tenascin_EGF`)

**Positional suffixes**:
- `_N` - N-terminal
- `_C` - C-terminal
- `_M` - Middle
- `_1st`, `_2nd`, `_3rd` - Preferred ECOD style

**Special cases**:
- `WHD_` prefix for Winged Helix domains
- Numbers like `_2`, `_3` for related but distinct families (e.g., `EGF`, `EGF_2`, `EGF_3`)

### DE - Definition
**Format**: `DE   One-line description`
**Length**: 80 characters or less
**Example**: `DE   Zona pellucida-like domain`

- Single line description of the family
- No period at end
- Concise but informative

### AU - Author
**Format**: `AU   Lastname F;ORCID-ID`
**Example**: 
```
AU   Bateman A;0000-0002-6982-4660
AU   Chothia C;
```

- One author per line
- Semicolon after name
- ORCID ID when known (format: 0000-0000-0000-0000)
- Most significant author listed first
- Use `add_author.pl` script to add yourself

### SE - Source of Seed
**Format**: `SE   Description of source`
**Examples**:
- `SE   Jackhmmer:P76213`
- `SE   TED:P76213_TED03`
- `SE   Swissprot_feature_table`
- `SE   ECOD:e4hfuA1`

### GA - Gathering Threshold
**Format**: `GA   XX.XX XX.XX;`
**Example**: `GA   25.00 15.00;`

- Two bit score thresholds (sequence, domain)
- Determines inclusion in full alignment
- Set manually during curation
- Format: sequence_threshold domain_threshold;

### TC - Trusted Cutoff
**Format**: `TC   XX.XX XX.XX;`
**Example**: `TC   25.00 16.10;`

- Lowest scores in full alignment (sequence, domain)
- Auto-generated, never manually set
- May refer to different sequences

### NC - Noise Cutoff  
**Format**: `NC   XX.XX XX.XX;`
**Example**: `NC   24.90 15.90;`

- Highest scores NOT in full alignment (sequence, domain)
- Auto-generated, never manually set
- May refer to different sequences

### BM - Build Model
**Format**: `BM   hmmbuild -o /dev/null HMM SEED`

- Command used to build HMM
- Standard HMMER3 command
- Never manually edit

### SM - Search Model
**Format**: `SM   hmmsearch -Z 47079205 -E 1000 --cpu 4 HMM pfamseq`

- Command used to search pfamseq
- -Z flag: database size (number of sequences)
- Never manually edit

### TP - Type
**Format**: `TP   Type`
**Options**: Family | Domain | Repeat | Motif | Coiled-coil | Disordered

**Guidelines**:
- **Family**: Default for complete proteins or uncertain cases
- **Domain**: Confident structural/functional domain with clear boundaries
- **Repeat**: Tandem or dispersed repeating sequences
- **Motif**: Short linear motifs (rare in Pfam)
- **Coiled-coil**: Predominantly coiled-coil structure
- **Disordered**: No stable structure, biased composition

## Header Section (Optional Fields)

### PI - Previous IDs
**Format**: `PI   old_id;another_id;`
**Example**: `PI   zona_pellucida;`

- Semicolon-separated list
- Most recent names on left
- Only edited by pfmove.pl script
- Non-compulsory field

### CL - Clan
**Format**: `CL   CLxxxx`
**Example**: `CL   CL0159`

- Clan accession to which family belongs
- Add only when evidence supports common ancestry
- Goes between TP and first WK/RN lines

## Reference Section

**CRITICAL**: The reference section MUST come AFTER the header section and BEFORE the comment section (CC lines).

**Typical order within reference section**:
1. WK (Wikipedia) - optional
2. RC (Reference Comment) - optional, appears before its corresponding RN
3. RN, RM, RT, RA, RL (literature references) - can have multiple sets
4. DR (Database references) - optional

### WK - Wikipedia Reference
**Format**: `WK   Article_name`
**Example**: `WK   CBS_domain`

- Wikipedia article name (English version)
- Will be appended to http://en.wikipedia.org/wiki/
- Underscores for spaces
- Can be added manually to DESC
- Goes after TP/CL and before references

### RC - Reference Comment
**Format**: `RC   Comment text`
**Example**: `RC   Discovery and naming of the CBS domain.`

- Optional comment about the following reference
- Appears immediately before its corresponding RN line
- Indicates what aspect of the paper is relevant
- Can have multiple RC lines for different references

### RN - Reference Number
**Format**: `RN   [#]`
**Example**: `RN   [1]`

- Sequential numbering in square brackets
- Precedes each literature reference

### RM - Reference Medline
**Format**: `RM   ########`
**Example**: `RM   1313375`

- PubMed identifier (PMID)
- 8-digit number (UI number from PubMed)
- Use `add_pubmed.pl` or `add_ref.pl` script

### RT - Reference Title
**Format**: `RT   Paper title line 1`  
         `RT   Continued on next line`
**Example**:
```
RT   A large domain common to sperm receptors (Zp2 and Zp3) and TGF-beta
RT   type III receptor.
```

- Can span multiple lines
- Each line starts with RT

### RA - Reference Author
**Format**: `RA   Lastname1 I, Lastname2 I, Lastname3 I;`
**Example**: `RA   Bork P, Sander C;`

- All authors on one line
- Format: Last name followed by initials
- Comma-separated
- Ends with semicolon

### RL - Reference Location
**Format**: `RL   Journal year;volume:pages.`
**Example**: `RL   FEBS Lett 1992;300:237-240.`

- Journal abbreviation (no periods)
- Year
- Volume
- Page range (not abbreviated)
- Check abbreviations at http://expasy.hcuge.ch/cgi-bin/jourlist?jourlist.txt

### DR - Database Reference
**Format**: `DR   DATABASE; identifier;`
**Examples**:
```
DR   PRINTS; PR00023;
DR   PROSITE; PDOC00577;
DR   PDB; 2nad A; 123; 332;
DR   SCOP; 7rxn; sf;
```

- External database cross-references
- Format varies by database
- Ends with semicolon
- Rarely used in modern Pfam

### DC - Database Comment
**Format**: `DC   Comment for database reference`

- Optional
- Rarely used

### ED - Excluded Domain
**Format**: `ED   accession.version/start-end; accession.version/start-end;`
**Example**: `ED   A0A3M6TSD3.1/99-190; A0A3M6TSD3.1/125-190;`

- Sequences to ignore in overlap checks
- Use ONLY as last resort
- Add using `~agb/Scripts/add_ED.pl`
- Must run pfmake after adding

## Comment Section

**CRITICAL**: The CC (comment) lines MUST be the LAST section of the DESC file. They come AFTER all references (WK, RC, RN, RM, RT, RA, RL, DR).

**Incorrect order** (DO NOT DO THIS):
```
TP   Domain
CC   This entry represents...
RN   [1]
RM   12345678
```

**Correct order**:
```
TP   Domain
RN   [1]
RM   12345678
RT   Paper title
RA   Authors;
RL   Journal 2023;123:456.
CC   This entry represents...
```

### CC - Comment
**Format**: `CC   Text (75 character limit per line)`
**Example**:
```
CC   This entry represents the Zona pellucida domain found in
CC   extracellular proteins. The domain is approximately 260 residues
CC   long and forms a conserved structure stabilised by disulfide
CC   bonds [1].
```

**Rules**:
- Maximum 75 characters per line
- Start with "This entry represents..."
- Include only factual information
- Use British English
- Cite references as [1] or [1,2] or [1-3]
- No speculation

**Good content**:
- What the domain/family represents
- Taxonomic distribution (when informative)
- Size/length information
- Structural features (experimentally determined)
- Conserved residues/motifs
- Domain architecture
- Experimentally verified functions [cite]

**Avoid**:
- Speculation based on context
- "may be", "could be", "suggests"
- Long sequences (>20 residues)
- Inferred function without evidence

**Internal comments** (not visible on website):
- Start line with `**`
- Below last CC line
- For curator notes only

## Links in CC Lines

### Pfam families
Format: `Pfam:PFxxxxx`
Example: "The protein also contains a GIY-YIG domain (Pfam:PF01541)"

### UniProt entries
Format: `Swiss:Accession` 
Example: "as seen in Swiss:P12345"

### EC numbers
Format: `EC:X.X.X.X`
Example: "classified as EC:3.4.21.4"

## Automated vs Manual Fields

### Never manually edit:
- AC (accession)
- TC (trusted cutoff)
- NC (noise cutoff)  
- BM (build command)
- SM (search command)
- HMM file
- PFAMOUT file
- ALIGN file
- scores file

### Edit with scripts only:
- PI (previous IDs) - use pfmove.pl
- ED (excluded domains) - use add_ED.pl
- RN/RM/RT/RA/RL - use add_pubmed.pl or add_ref.pl
- AU - use add_author.pl

### Manually editable:
- ID (but use pfmove.pl to change)
- DE
- GA
- TP
- CL (but use -add_to_clan or -change_clan flags)
- SE
- CC
- WK

## Special Procedures

### Changing ID
Use pfmove script, not manual editing:
```bash
pfmove PF12345 New_name
```

### Adding to Clan
```bash
pfci PF12345 -add_to_clan -m "Based on ECOD classification"
```

### Changing Clan
```bash  
pfci PF12345 -change_clan -m "Merged clans CL0123 and CL0456"
```

### Checking in DESC-only changes
```bash
pfci PF12345 -onlydesc -m "Updated annotation"
```
