# Pfam Curation Workflows

Step-by-step procedures for common Pfam curation tasks.

## Building a New Family

### Starting from a Single Sequence

```bash
# 1. Get the sequence
pfetch P12345 > sequence.fa

# 2. View and create SEED alignment
belvu sequence.fa
# Save as SEED in Stockholm format

# 3. Build HMM and search
pfbuild

# 4. Set thresholds and create ALIGN
pfmake -e 0.01

# 5. View results
less PFAMOUT
belvu ALIGN
```

### Iteration Cycle

```
pfbuild -> pfmake -> view ALIGN -> edit/extend SEED -> repeat
```

### Extending Boundaries

```bash
extend.pl -n 30 -c 30 -align ALIGN -m > extended.sto
belvu extended.sto
# Edit and save as SEED, then rebuild
```

### Quality Control

```bash
# Check for overlaps and DESC issues
pqc-all working_directory id_name

# Check only overlaps
pqc-overlap-rdb working_directory id_name
```

### Adding New Family to Pfam

```bash
# From parent directory:
pfnew working_directory

# If adding to clan:
pfnew working_directory -add_to_clan -m "Based on ECOD classification"
```

## Iterating an Existing Family

```bash
# 1. Check out family
pfco PF00100
cd PF00100

# 2. Examine and extend alignment
extend.pl -n 30 -c 30 -align ALIGN -m > extended.sto
belvu extended.sto

# 3. Edit and save as SEED
# 4. Rebuild
pfbuild
pfmake -e 0.01

# 5. Check results and repeat if needed
# 6. Quality control
cd ..
pqc-all PF00100 PF00100

# 7. Check in
pfci PF00100 -m "Iterated family to expand coverage"
```

## Editing Family Annotation

### DESC File Only Changes

```bash
# 1. Check out family
pfco PF00100
cd PF00100

# 2. Edit DESC file
emacs DESC

# 3. Add references if needed
add_pubmed.pl 12345678

# 4. Check DESC format
cd ..
pqc-all PF00100 PF00100

# 5. Check in DESC-only changes
pfci PF00100 -onlydesc -m "Updated annotation"
```

### Changing Family ID

```bash
# Never edit ID line directly!
# Use pfmove script:
pfci PF00100 -m "Final changes before rename"
cd ..
rm -rf PF00100
pfmove PF00100 New_name
```

## Adding Families to Clans

### Quick Method

```bash
~agb/Scripts/add_to_clan.pl -clan CL0373 -family PF10124 \
  -reason 'Based on ECOD classification'
```

### Standard Method

```bash
pfco PF00100
cd PF00100
# Add CL line to DESC between TP and RN lines
pfci PF00100 -add_to_clan -m "Added to clan based on ECOD"
```

## Handling Overlaps

### Resolution Strategies

1. **Trim Boundaries**: Remove overlapping termini in belvu
2. **Raise Thresholds**: Increase GA thresholds to exclude low-scoring overlaps
3. **Add to Clan**: If families are truly related
4. **Use ED Lines**: Last resort for false positives

## Quick Reference Commands

```bash
# Family operations
pfco PF00100                          # Check out
pfci -m 'message'                     # Check in
pfnew dir                             # New family
pfinfo PF00100                        # View info
pfmove PF00100 New_name               # Rename

# Building
pfbuild                               # Build HMM
pfmake -e 0.01                        # Make ALIGN

# Alignment
belvu SEED                            # View SEED
extend.pl -n 30 -c 30 -align ALIGN -m # Extend

# Quality control
pqc-all dir id                        # All checks
pqc-overlap-rdb dir id                # Overlaps only

# References
add_pubmed.pl 12345678                # Add from PMID
add_author.pl                         # Add yourself

# Clans
clco CL0000                           # Check out clan
clci CL0000 -m 'message'              # Check in clan
```
