# Pfam Annotation Writing Guidelines

Comprehensive guide to writing high-quality Pfam annotations that are factual, concise, and informative.

## Core Writing Principles

1. **Facts only**: Include only experimentally verified information
2. **British English**: Use British spellings consistently
3. **Concise**: Maximum 75 characters per CC line
4. **Clear**: Start with "This entry represents..."
5. **Cited**: Reference all experimental claims
6. **Honest**: State when function is unknown

## Language Standards

### British English Spellings

| British (✓) | American (✗) |
|-------------|--------------|
| localised | localized |
| organisation | organization |
| characterised | characterized |
| stabilised | stabilized |
| recognised | recognized |

### Avoid Greek Symbols

Write out Greek letters: alpha, beta, gamma, delta, omega (not α, β, γ, δ, ω)

## Annotation Structure

### Opening Statement (Required)

**Template**: "This entry represents the [type] [name] [context]"

**Examples**:
```
This entry represents the Zona pellucida domain found in extracellular
proteins.

This entry represents a family of uncharacterised proteins found in
Gram-negative bacteria.
```

### What to Include

✓ Experimentally verified functions [cite]
✓ Structural features (experimentally determined)
✓ Conserved sequence motifs (short, diagnostic)
✓ Domain architecture (factual observation)
✓ Taxonomic distribution (when informative)
✓ Subcellular localisation (if experimentally determined)

### What NOT to Include

✗ Genomic context speculation
✗ Similarity-based speculation
✗ Phrases: "may be", "could be", "possibly", "suggests"
✗ Long motifs (>20 residues)
✗ Complete genome paper citations

## Domain vs Protein Functions

**CRITICAL**: Only attribute functions to domains if there's clear evidence that specific domain is responsible.

**Correct**:
```
This entry represents the C-terminal domain of RNA helicase X. The
full-length protein unwinds RNA duplexes [1], though the specific
function of this domain remains to be determined.
```

**Incorrect**:
```
This entry represents the C-terminal domain of RNA helicase X. The
domain unwinds RNA duplexes [1].
(Without evidence this domain performs that function)
```

## Examples of Well-Written Annotations

### Example 1: Known Function
```
CC   This entry represents the Zona pellucida domain found in
CC   extracellular proteins involved in fertilisation. The domain is
CC   approximately 260 residues long and forms a conserved immunoglobulin
CC   -like fold stabilised by disulfide bonds [1]. It is found in egg
CC   coat proteins ZP1, ZP2, and ZP3, as well as transforming growth
CC   factor-beta receptor type III. The domain mediates species-specific
CC   sperm-egg recognition [2].
```

### Example 2: Domain of Unknown Function
```
CC   This entry represents a domain of unknown function found primarily
CC   in Gram-negative bacteria. The domain is approximately 120 residues
CC   long and contains two highly conserved cysteine residues. It is
CC   typically found at the C-terminus of proteins that also contain an
CC   ABC transporter domain (Pfam:PF00005). The function of this domain
CC   remains to be determined.
```

## Citation Guidelines

### When to Cite

Cite references for:
- Experimental functional characterisation
- Structural determination
- Biochemical properties
- Subcellular localisation studies

### Citation Format

```
[1]          Single reference
[1,2]        Two references
[1-3]        Range of references
```

## Quality Checklist

- [ ] Opens with "This entry represents..."
- [ ] All CC lines ≤75 characters
- [ ] British English spellings
- [ ] No Greek symbols
- [ ] No speculation
- [ ] All functional claims cited
- [ ] Clear protein/domain function distinction
- [ ] Honest about unknown functions
